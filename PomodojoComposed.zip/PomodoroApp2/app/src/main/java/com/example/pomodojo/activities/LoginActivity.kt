package com.example.pomodojo.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pomodojo.FaceScan
import com.example.pomodojo.Main
import com.example.pomodojo.SignUp
import com.example.pomodojo.compose.screens.LoginScreen
import com.example.pomodojo.viewmodels.LoginViewModel

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    LoginScreenWithViewModel()
                }
            }
        }
    }

    @Composable
    fun LoginScreenWithViewModel(viewModel: LoginViewModel = viewModel()) {
        viewModel.navigateToSignUp.observe(this@LoginActivity) {
            startActivity(Intent(this@LoginActivity, SignUp::class.java))
        }

        viewModel.navigateToFaceScan.observe(this@LoginActivity) {
            startActivity(Intent(this@LoginActivity, FaceScan::class.java))
        }

        viewModel.navigateToHome.observe(this@LoginActivity) {
            startActivity(Intent(this@LoginActivity, Main::class.java))
        }

        LoginScreen(viewModel)
    }
}
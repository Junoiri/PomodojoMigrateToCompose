package com.example.pomodojo.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.pomodojo.SnackBar
import com.google.firebase.auth.FirebaseAuth

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    private val _navigateToSignUp = MutableLiveData<Unit>()
    val navigateToSignUp: LiveData<Unit> = _navigateToSignUp

    private val _navigateToFaceScan = MutableLiveData<Unit>()
    val navigateToFaceScan: LiveData<Unit> = _navigateToFaceScan

    private val _navigateToHome = MutableLiveData<Unit>()
    val navigateToHome: LiveData<Unit> = _navigateToHome

    fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { login ->
                if (login.isSuccessful) {
                    // Placeholder for navigation to home
                    // _navigateToHome.postValue(Unit)
                } else {
                    SnackBar.showSnackBar(getApplication(), "Authentication failed.")
                }
            }
    }

    fun forgotPassword(email: String) {
        if (email.isEmpty()) {
            SnackBar.showSnackBar(getApplication(), "Please enter your email address.")
            return
        }

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { sent ->
                if (sent.isSuccessful) {
                    SnackBar.showSnackBar(getApplication(), "Password reset email sent.")
                } else {
                    SnackBar.showSnackBar(getApplication(), "Error in sending reset email.")
                }
            }
    }

    fun googleLogin() {
        // Placeholder for Google login functionality
        // val signInIntent = GoogleSignIn.getClient(getApplication(), GoogleSignInOptions.DEFAULT_SIGN_IN).signInIntent
        // startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    fun navigateToSignUp() {
        // Placeholder for navigation to sign up
        // _navigateToSignUp.postValue(Unit)
    }

    fun navigateToFaceScan() {
        // Placeholder for navigation to face scan
        // _navigateToFaceScan.postValue(Unit)
    }

    // Placeholder for handling activity result
    // @Deprecated("Deprecated in Java")
    // override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    //     super.onActivityResult(requestCode, resultCode, data)
    //     if (requestCode == RC_SIGN_IN) {
    //         val task = GoogleSignIn.getSignedInAccountFromIntent(data)
    //         try {
    //             val account = task.getResult(ApiException::class.java)
    //             if (account != null) {
    //                 googleAuthentication(account)
    //             }
    //         } catch (e: ApiException) {
    //             SnackBar.showSnackBar(getApplication(), "Google sign in failed")
    //         }
    //     }
    // }

    // Placeholder for Google authentication
    // private fun googleAuthentication(account: GoogleSignInAccount) {
    //     val credential = GoogleAuthProvider.getCredential(account.idToken, null)
    //     auth.signInWithCredential(credential)
    //         .addOnCompleteListener { auth ->
    //             if (auth.isSuccessful) {
    //                 _navigateToHome.postValue(Unit)
    //             } else {
    //                 SnackBar.showSnackBar(getApplication(), "Google Authentication failed")
    //             }
    //         }
    // }

    companion object {
        // Placeholder for request code
        // private const val RC_SIGN_IN = 9001
    }
}